﻿using System;
namespace Restsharp_Csharp.model
{
    public class Account
    {
        public string Facebook_id { get; set; }
        public string Google_play_id { get; set; }
        public string Player_id { get; set; }
        public string Email_id { get; set; }
      


    }
}
