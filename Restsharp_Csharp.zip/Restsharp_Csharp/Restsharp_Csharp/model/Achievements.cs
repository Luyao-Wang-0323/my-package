﻿using System;
namespace Restsharp_Csharp.model
{
    public class Achievements
    {
        public string Achievement_desc { get; set; }
        public string Achievement_name { get; set; }
        public string Max_progress { get; set; }
        public string Player_id{ get; set; }
        public string Current_progress { get; set; }
    }
}
