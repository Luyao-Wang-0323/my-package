﻿using System;
using RestSharp;
using System.Collections.Generic;
using Restsharp_Csharp.model;
namespace Restsharp_Csharp.caller
{
    public class ProjectAPI:IClassAPI
    {
        private RestClient client;

        public ProjectAPI(string Url)
        {
            client = new RestClient(Url);
        }

        public List<Account> Getall()
        {
            var request = new RestRequest("Account", Method.GET);
            var response = client.Execute<List<Account>>(request);
            return response.Data;
        }
     
        public List<Account> Getmany(List<string> Players_id)
        {
            List<Account> list = new List<Account>();
            for (int i = 0; i < Players_id.Count; i++)
            {
                var request = new RestRequest("Account/" + Players_id[i], Method.GET);
                var response = client.Execute<Account>(request);
                list.Add(response.Data);
            }
            return list;

        }
        public Account Getone(string Player_id)
        {
            var request = new RestRequest("Account/" + Player_id, Method.GET);
            var response = client.Execute<Account>(request);
            return response.Data;
        
        }
        
        public string Update(string Player_id, Account account)
        {
            var request = new RestRequest("Account/" + Player_id, Method.PUT);
            request.AddJsonBody(account);
            client.Execute(request);
            return "update sucess";
        }

        public string Creatone(string Player_id, Account account)
        {
            var request = new RestRequest("Account", Method.POST);
            request.AddJsonBody(account);
            client.Execute(request);
            return "create sucess";
        }

        public string Creatmany(List<Account> accounts)
        {
            var request = new RestRequest("Account", Method.POST);
            for (int i = 0; i < accounts.Count; i++)
            {
                request.AddJsonBody(accounts[i]);
                client.Execute(request);
            }
            return "create_many sucess";
        }

        public string Deleteall()
        {
            var request = new RestRequest("Account" , Method.DELETE);
            client.Execute(request);
            return "delete sucess";
        }

        public string Deleteone(string Player_id)
        {
            var request = new RestRequest("Account/" + Player_id, Method.DELETE);
            client.Execute(request);
            return "delete_one sucess";
        }

        public string Deletemany(List<string> Players_id)
        {
            for (int i = 0; i < Players_id.Count; i++)
            {
                var request = new RestRequest("Account/" + Players_id[i], Method.DELETE);
                client.Execute(request);
            }
                
            return "delete_many sucess";
        }

        //public List<Achievements> Getall_achievement();
        //public List<Achievements> Getmany_achievement(List<string> Players_id);
        //public Achievements Getone_achievement(string Player_id);
        //public string Update_achievement(string Player_id, Achievements account)
        //public string Creatone_achievement(string Player_id, Achievements account);
        //public string Creatmany_achievement(List<Achievements> accounts);
        //public string Deleteall_achievement();
        //public string Deleteone_achievement();
        //public string Deletemany_achievement();


    }
}
