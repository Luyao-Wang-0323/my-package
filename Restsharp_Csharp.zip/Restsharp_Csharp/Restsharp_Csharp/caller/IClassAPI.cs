﻿using System;
using System.Collections.Generic;
using Restsharp_Csharp.model;
namespace Restsharp_Csharp.caller
{
   
    public interface IClassAPI
    {
      

        List<Account> Getall();
        List<Account> Getmany(List<string> Players_id);
        Account Getone(string Player_id);
        string Update(string Player_id, Account account);
        string Creatone(string Player_id, Account account);
        string Creatmany(List<Account> accounts);
        string Deleteall();
        string Deleteone(string Player_id);
        string Deletemany(List<string> Players_id);

        //List<Achievements> Getall_achievement();
        //List<Achievements> Getmany_achievement(List<string> Players_id);
        //Achievements Getone_achievement(string Player_id);
        //string Update_achievement(string Player_id, Achievements account);
        //string Creatone_achievement(string Player_id, Achievements account);
        //string Creatmany_achievement(List<Achievements> accounts);
        //string Deleteall_achievement();
        //string Deleteone_achievement(string Player_id);
        //string Deletemany_achievement(List<string> Players_id);


    }
}
