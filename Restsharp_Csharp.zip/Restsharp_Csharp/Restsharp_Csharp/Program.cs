﻿using System;
using Restsharp_Csharp.caller;

namespace Restsharp_Csharp
{
    class Program
    {
        static void Main(string[] args)
        {
            var api = new ProjectAPI("http://localhost:9075/api/");

            var accounts = api.Getall();
            foreach (var account in accounts)
            {
                Console.WriteLine(account);
            }
            //Console.WriteLine("Hello World!");
        }
    }
}
